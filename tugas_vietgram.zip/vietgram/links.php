<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Links 4 u</title>
</head>
<body>
    <ul>
        <li>
            <a href="/images">Download images here</a>
        </li>
        <li>
                <a href="http://github.com/nomadcoders/vietgram">My code</a>
        </li>
        <li>
            <a href="https://www.bootstrapcdn.com/fontawesome/">Font awesome</a>
        </li>
    </ul>
</body>
</html>